package com.app_republic.kora;

import com.app_republic.kora.data.StaticConfig;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Utils {

    public static long getMillisFromDate(String match) {
        Calendar calendar = Calendar.getInstance();
        String[] date = match.split(" ");
        int year = Integer.parseInt(date[0]);
        int month = Integer.parseInt(date[1]) - 1;
        int day = Integer.parseInt(date[2]);
        int hour = Integer.parseInt(date[3]);
        int minute = Integer.parseInt(date[4]);

        calendar.set(year,month,day,hour,minute);

        return calendar.getTimeInMillis() - StaticConfig.HOUR_MILLIS * 2;
    }

    public static String getReadableDate(Calendar cal) {
        Date date=cal. getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate=dateFormat. format(date);

        return formattedDate;
    }

    public static String getDay(Calendar cal) {
        Date date=cal. getTime();
        SimpleDateFormat outFormat = new SimpleDateFormat("EEEE");
        String formattedDate = outFormat.format(date);

        return formattedDate;
    }
}
