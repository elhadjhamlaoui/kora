package com.app_republic.kora.request;

import androidx.annotation.Nullable;

import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.moudjib.quizz.utils.Utils;

import org.json.JSONArray;

import java.util.Map;

import static com.android.volley.Request.Method.GET;
import static com.moudjib.quizz.utils.Constant.API_BASE;
import static com.moudjib.quizz.utils.Constant.API_MODULES;

public class GetMatches extends JsonArrayRequest {

    String UID;
    public GetMatches(String UID,
                      Response.Listener<JSONArray> listener,
                      @Nullable Response.ErrorListener errorListener) {

        super(GET, API_BASE + API_MODULES, null, listener, errorListener);

        this.UID = UID;

    }


    @Override
    public Map<String, String> getHeaders() {
        Map<String, String> params = Utils.getAuthorizationHeader(UID);

        return params;
    }
}
