package com.app_republic.kora.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app_republic.kora.R;
import com.app_republic.kora.Utils;
import com.app_republic.kora.data.StaticConfig;
import com.app_republic.kora.model.Match;
import com.github.jhonnyx2012.horizontalpicker.DatePickerListener;
import com.github.jhonnyx2012.horizontalpicker.HorizontalPicker;
import com.google.gson.Gson;

import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static com.app_republic.kora.data.StaticConfig.BASE_URL;
import static com.app_republic.kora.data.StaticConfig.COMING;
import static com.app_republic.kora.data.StaticConfig.CURRENT;
import static com.app_republic.kora.data.StaticConfig.ENDED;
import static com.app_republic.kora.data.StaticConfig.GET_MATCHES;

public class MatchesFragment extends Fragment implements DatePickerListener {

    OkHttpClient client;

    ArrayList<Match> current_list = new ArrayList<>();
    ArrayList<Match> coming_list = new ArrayList<>();
    ArrayList<Match> ended_list = new ArrayList<>();

    Adapter current_adapter,ended_adapter,coming_adapter;
    RecyclerView current_recycler;
    RecyclerView ended_recycler;
    RecyclerView coming_recycler;
    Handler mainHandler;
    Calendar calendar;
    public MatchesFragment() {
        // Required empty public constructor
    }

    public static MatchesFragment newInstance() {
        MatchesFragment fragment = new MatchesFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        client = new OkHttpClient();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_matches, container, false);

        current_recycler = view.findViewById(R.id.current_recycler);
        ended_recycler = view.findViewById(R.id.ended_recycler);
        coming_recycler = view.findViewById(R.id.coming_recycler);

        current_adapter = new Adapter(getActivity(),current_list,CURRENT);
        ended_adapter = new Adapter(getActivity(),ended_list,ENDED);
        coming_adapter = new Adapter(getActivity(),coming_list,COMING);

        current_recycler.setAdapter(current_adapter);
        ended_recycler.setAdapter(ended_adapter);
        coming_recycler.setAdapter(coming_adapter);

        current_recycler.setLayoutManager(new LinearLayoutManager(getActivity()));
        ended_recycler.setLayoutManager(new LinearLayoutManager(getActivity()));
        coming_recycler.setLayoutManager(new LinearLayoutManager(getActivity()));


        mainHandler = new Handler(Looper.getMainLooper());



        calendar = Calendar.getInstance();

        getMatches();

        HorizontalPicker picker = view.findViewById(R.id.datePicker);

        picker
                .setListener(this);

        picker
                .setDays(20)
                .setOffset(10)
                .setDateSelectedColor(getActivity().getResources().getColor(android.R.color.black))
                .setDateSelectedTextColor(getActivity().getResources().getColor(android.R.color.white))
                .setMonthAndYearTextColor(getActivity().getResources().getColor(android.R.color.white))
                .setTodayButtonTextColor(getActivity().getResources().getColor(R.color.colorAccent))
                .setTodayDateTextColor(getActivity().getResources().getColor(android.R.color.black))
                .setTodayDateBackgroundColor(getActivity().getResources().getColor(android.R.color.white))
                .setUnselectedDayTextColor(getActivity().getResources().getColor(android.R.color.white))
                .setDayOfWeekTextColor(getActivity().getResources().getColor(android.R.color.white))
                .setUnselectedDayTextColor(getActivity().getResources().getColor(android.R.color.white))
                .showTodayButton(true)
                .init();
        picker.setBackgroundColor(getActivity().getResources().getColor(R.color.colorPrimary));
        picker.setDate(new DateTime());

        return view;
    }

    @Override
    public void onDateSelected(DateTime dateSelected) {
        calendar.setTimeInMillis(dateSelected.getMillis());
        getMatches();
    }


    class Adapter extends RecyclerView.Adapter<viewHolder> {

        Context context;
        ArrayList<Match> list;
        String type;

        public Adapter(Context context, ArrayList<Match> list, String type) {
            this.context = context;
            this.list = list;
            this.type = type;
        }

        @NonNull
        @Override
        public viewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(getActivity())
                    .inflate(R.layout.item_match, viewGroup, false);

            return new viewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull viewHolder viewHolder, int i) {

            Match match = list.get(i);

            if (type.equals(StaticConfig.ENDED)) {
                viewHolder.result.setText(match.getLiveRe1()+" - "+match.getLiveRe2());
            } else if (type.equals(StaticConfig.CURRENT)) {
                viewHolder.result.setText(match.getLiveRe1()+" <"+match.getActualMinutes()+"> "+match.getLiveRe2());
            } else if (type.equals(StaticConfig.COMING)) {
                viewHolder.result.setText(match.getFullTime());
            }

            viewHolder.name1.setText(match.getLiveTeam1());
            viewHolder.name2.setText(match.getLiveTeam2());



        }

        @Override
        public int getItemCount() {
            return list.size();
        }
    }

    class viewHolder extends RecyclerView.ViewHolder {

        ImageView logo1, logo2;
        TextView name1, name2, result;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            logo1 = itemView.findViewById(R.id.logo_team_1);
            logo2 = itemView.findViewById(R.id.logo_team_2);
            name1 = itemView.findViewById(R.id.name_team_1);
            name2 = itemView.findViewById(R.id.name_team_2);
            result = itemView.findViewById(R.id.result_text);
        }
    }

    public void getMatches() {
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH)+1;
        int year = calendar.get(Calendar.YEAR);

        current_list.clear();
        ended_list.clear();
        coming_list.clear();

        HttpUrl.Builder urlBuilder = HttpUrl.parse(BASE_URL+GET_MATCHES).newBuilder();
        String url = urlBuilder.build().toString();

        RequestBody formBody = new FormBody.Builder()
                .add("accessToken", "")
                .add("is_android", "1")
                .add("date", day+"/"+month+"/"+year)
                .build();

        Request request = new Request.Builder()
                .url(url)
                .post(formBody)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            public void onResponse(Call call, Response response)
                    throws IOException {
                try {
                    String string = response.body().string();
                    JSONObject object = new JSONObject(string);
                    JSONArray items = object.getJSONArray("items");

                    for (int i = 0; i < items.length(); i++) {
                        String jsonString = items.getJSONObject(i).toString();
                        Match match;
                        Gson gson = new Gson();
                        match= gson.fromJson(jsonString,Match.class);

                        long now = System.currentTimeMillis();
                        int delay = Integer.parseInt(match.getLiveM3());
                        long time = Utils.getMillisFromDate(match.getFullDatetimeSpaces()) - delay;

                        long difference = now - time;

                        if (difference > 0) {
                            ended_list.add(match);

                        } else {
                            int minutes = Integer.parseInt(match.getActualMinutes());
                            if (minutes > 0) {
                                current_list.add(match);
                            } else {
                                coming_list.add(match);

                            }

                        }
                    }


                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            current_adapter.notifyDataSetChanged();
                            ended_adapter.notifyDataSetChanged();
                            coming_adapter.notifyDataSetChanged();
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
                // ...
            }

            public void onFailure(Call call, IOException e) {
                //fail();
            }
        });
    }


}
