package com.app_republic.kora.data;

import java.util.Calendar;

public class StaticConfig {
    public static String BASE_URL = "https://yalla-group.com/api-v3.4.520/api/";
    public static String GET_MATCHES = "getMatches";
    public static String ENDED = "ended";
    public static String COMING = "coming";
    public static String CURRENT = "current";
    public static long HOUR_MILLIS = 60 * 60 * 1000;



}
